import UIKit

var greeting = "Hello, playground"
var distance : Double
var maxWeight : Int = 130
print("Your max weight is \(maxWeight) pounds")
print("Hello, All \rWelcome to Swift programming")
var x : Double = 15
var y = 25.0
y = x
var x1 : Int = 2
var y1 : Int = 7
var z1 : Int = 5
if(x1>y1 && x1>z1){
    
}
